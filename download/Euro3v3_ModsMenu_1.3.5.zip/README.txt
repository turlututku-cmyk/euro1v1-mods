﻿EURO3V3 MODS MENU  v1.3.5
=========================
What it is: an in-game Mods menu (BepInEx plugin) with crosshair changer, FPS counter, clip maker + 3D clip editor with video render,
hit sounds, damage numbers, RTX mode, better visuals, freecam (team only) and more. Everything is client-side.

INSTALL
1. Install Euro3v3 from Steam (same game version as the one the mod was made on: Unity 2022.3.62f2).
2. Extract this whole zip INTO the game folder (Steam > Euro3v3 > Manage > Browse local files) and choose "replace" if asked.
   You should end up with winhttp.dll next to Euro3v3.exe, plus the BepInEx, dotnet and Mods folders.
3. Start the game from Steam. The FIRST launch takes 1-3 minutes on a black screen while BepInEx prepares itself. That is normal.
4. In the game press F8, or use the new "Mods" button in the Play menu (After Campaign) or the pause menu (after Edit Profile).
5. Open the FEATURED tab and press GET on the mods you want.

NOTES
- Needs about 2 GB of free RAM on top of the game. Close other heavy programs if the game crashes on start.
- Use mods at your own risk in online matches: any modified game client can be flagged by the game's developers. Practice and private games are the safe choice.
- To uninstall: delete winhttp.dll, doorstop_config.ini, the BepInEx and dotnet folders from the game folder.
- Clips are saved in Mods\Clips, videos in Mods\Videos, backups in Mods\Backups. They stay on your PC.
