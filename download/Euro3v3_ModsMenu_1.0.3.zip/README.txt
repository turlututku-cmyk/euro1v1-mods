﻿EURO MODS MENU  v1.0.3
=====================
An in-game Mods menu (BepInEx plugin) with a growing list of client-side mods. Everything is optional: nothing is switched on
until you press GET on it in the menu.

TABS
- FEATURED  popular picks that are worth downloading (shown in yellow). Damage Numbers is the first one.
- NEW       only the very latest additions, with a NEW tag. A laughing face marks the joke mods.
- DOWNLOAD  the whole list in one place, with search.
- INSTALLED the mods you have, with a switch for each.
Every mod has its own picture. Its version is its fix count (v1.0.4 = 4 fixes): hover the title on its page to see what changed.

WHAT IS INSIDE
Damage Numbers, Crosshair Changer, Crosshair Profiles, FPS counter/limiter/graph, Clock, Input Display, Hit Sounds, Better Visuals,
RTX Mode, Clip Maker (3D replay viewer and video render), Team Freecam, Menu Music Player, Kill Messages, Announcer, Kill Confetti,
Session Stats (leaderboard that updates at the end of each round), Aim Trainer (six drills and a warm-up routine), Low Health Warning,
Death Taunts, Sad Trombone, Scoreboard Screenshot, Chat Macros, Performance Coach, Chat Filter, Build Trainer, Practice Launcher,
Match Found Alert, Team Panel and Combat Log.

KEYS
Every hotkey can be changed: open the mod's page, click the key box, press the new key. Esc cancels, Delete unbinds, RESET restores the default.
The menu key itself is at the bottom right of the menu. Defaults: F8 menu, F12 screenshot, F2 aim trainer, F3 session overlay, F4 build trainer,
F6 freecam, F7 save clip, Shift+F7 record clip, F9 next crosshair profile, Alt+1..6 chat macros.

INSTALL
1. Install Euro3v3 from Steam (same game version the mod was made on: Unity 2022.3.62f2).
2. Extract this whole zip INTO the game folder (Steam > Euro3v3 > Manage > Browse local files), choose "replace" if asked.
   You should end up with winhttp.dll next to Euro3v3.exe, plus the BepInEx, dotnet and Mods folders.
3. Start the game. The FIRST launch takes 1-3 minutes on a black screen while BepInEx prepares itself. That is normal.
4. Press F8, or use the "Mods" button in the Play menu (after Campaign) or the pause menu (after Edit Profile).
5. Open FEATURED, NEW or DOWNLOAD and press GET on the mods you want.

NOTES
- Needs about 2 GB of free RAM on top of the game. Close other heavy programs if the game crashes on start.
- Use mods at your own risk in online matches: any modified game client can be flagged by the game's developers.
- Fair play: no wallhacks, aim assist or hidden information. Practice mods (Aim Trainer, Build Trainer) refuse to run with other players.
  Team Panel shows only your own team.
- Updating: extract a newer zip over the old one. Your settings are kept (they live in BepInEx\config).
- To uninstall: delete winhttp.dll, doorstop_config.ini, the BepInEx and dotnet folders from the game folder.
