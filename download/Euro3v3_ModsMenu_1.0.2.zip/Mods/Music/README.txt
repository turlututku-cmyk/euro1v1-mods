Put your own .mp3 / .wav / .ogg tracks here for the Menu Music Player mod.
