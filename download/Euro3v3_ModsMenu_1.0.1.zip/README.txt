﻿EURO MODS MENU  v1.0.1
=====================
An in-game Mods menu (BepInEx plugin). Currently available to download from the menu: DAMAGE NUMBERS
(a floating number for the damage of each shot, healing +N, kill tag, your choice of position).
Everything is client-side.

INSTALL
1. Install Euro3v3 from Steam (same game version the mod was made on: Unity 2022.3.62f2).
2. Extract this whole zip INTO the game folder (Steam > Euro3v3 > Manage > Browse local files), choose "replace" if asked.
   You should end up with winhttp.dll next to Euro3v3.exe, plus the BepInEx, dotnet and Mods folders.
3. Start the game. The FIRST launch takes 1-3 minutes on a black screen while BepInEx prepares itself. That is normal.
4. Press F8, or use the "Mods" button in the Play menu (after Campaign) or the pause menu (after Edit Profile).
5. Open the FEATURED tab and press GET on Damage Numbers.

NOTES
- Needs about 2 GB of free RAM on top of the game. Close other heavy programs if the game crashes on start.
- Use mods at your own risk in online matches: any modified game client can be flagged by the game's developers.
- Updating: extract a newer zip over the old one. Your settings are kept (they live in BepInEx\config).
- To uninstall: delete winhttp.dll, doorstop_config.ini, the BepInEx and dotnet folders from the game folder.
